<?php 
include("includes/header.php");
 ?>
	

	<div class="main_column column">
		This is a profile page!


	</div>




	</div>
</body>
</html>